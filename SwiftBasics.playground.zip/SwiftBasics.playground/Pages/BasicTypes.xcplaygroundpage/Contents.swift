//: [Previous](@previous)

import Foundation

//String
let greeting:String = "Hello, world!"

//Reference
let test1 = greeting

//Boolean
let test2:Bool = true
let test3:Bool = false

//Date
let test4:Date = Date()

//Number
let test5:Int = 1

//use double for math
let test6:Double = 1.0

//use CGFloat for UI (width, height px,...)
let test7:CGFloat = 1.0

//: [Next](@next)
